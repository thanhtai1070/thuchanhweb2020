<?php
if (!extension_loaded('pdo_mysql')) {
echo 'Pdo_mysql is unavailable';
}
else echo 'PDO is installed!';
?>