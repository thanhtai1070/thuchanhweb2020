Tạm ngừng 40 giây!<?php
sleep(40);
phpinfo();
?>