<h1 style="width:500px; margin:0 auto">Trang: Example_01</h1>
<?php
phpinfo();
?>