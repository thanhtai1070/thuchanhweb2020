<?php	
define("HOST", "localhost");
define("DATABASE", "bookstore_vn");
define("USERNAME", "root");
define("PASSWORD", "");

